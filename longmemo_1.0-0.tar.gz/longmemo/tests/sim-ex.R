library(longmemo)

set.seed(162)

simARMA0(120, 0.6)
simARMA0(120, 0.9)


simFGN0(120, 0.6)
simFGN0(120, 0.9)

## .5 and 1.0 do not work yet!

