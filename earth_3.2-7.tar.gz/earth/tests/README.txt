This does a basic test to check that earth ported without problems.
For more comprehensive tests, see earth/src/tests
