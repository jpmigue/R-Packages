confusion <-
function (object, ...) 
UseMethod("confusion")

