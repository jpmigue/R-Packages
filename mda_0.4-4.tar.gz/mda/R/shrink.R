shrink <-
function (object, ...) 
UseMethod("shrink")

