##' @method print Hist
##' @S3method print Hist
print.Hist <- function(x,...){
  summary(x)
}
