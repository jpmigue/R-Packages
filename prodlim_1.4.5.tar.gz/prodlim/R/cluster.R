## Used to specify clustered structures
## Similar as the function strata specifies strata for a discrete predictor. 
cluster <- function(x)x
