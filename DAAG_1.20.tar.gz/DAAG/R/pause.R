`pause` <-
function () 
{
    if(interactive()) readline("Pause. Press <Enter> to continue...")
    invisible()
}
