The tests in this directory are too slow to be part of the standard
CRAN tests.  I run them manually before submitting a new version of
this package to CRAN.
