library(testthat)
library(RANN)

test_check("RANN")
