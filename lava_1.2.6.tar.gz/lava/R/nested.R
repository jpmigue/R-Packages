is.nested.lvm <- function(object,...) {
    objects <- list(object, ...)
    
}
 
